"""
AI Impact Summit 2026 — Comprehensive Data Analysis
=====================================================
B.Tech Project · IIIT Delhi · Dept. of Social Science & Humanities
Team: Anshul Jain, Dhruv Kantroo, Siddhant Gautam, Sukhmani Kaur
Supervisors: Suriya Krishna B S · Deepshikha Manohar

Data Credit: Apar Gupta, Internet Freedom Foundation
Source: https://docs.google.com/spreadsheets/d/1DfDw7C5dbMtOWdYbVwKYoi0G6PANCiMp7LbJDxGMglE/

Covers 3 datasets:
  - Pre-Summit Events    (450 events)
  - Main Summit Sessions (327 sessions)
  - Other Events         (30 events)
  Total: 807 events documented

Charts Generated:
  C1  — Event overview summary cards
  C2  — Pre-summit theme distribution
  C3  — Main summit theme distribution
  C4  — Theme comparison: Pre vs Main
  C5  — Geographic distribution
  C6  — Top organisers
  C7  — Word cloud of all event titles
  C8  — Sentiment analysis
  C9  — Monthly trend of pre-summit events
  C10 — Top keywords and bigrams (text mining)
  C11 — Organiser type breakdown
  C12 — Theme × Organiser type heatmap
"""

import pandas as pd
import numpy as np
import re
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyBboxPatch
from collections import Counter
from wordcloud import WordCloud
from textblob import TextBlob

# ── Load Data ────────────────────────────────────────────────────────────────
xl    = pd.ExcelFile('AI_Impact_Summit_Events_.xlsx')
pre   = xl.parse('Pre Summit Events')
main  = xl.parse('Main Event')
other = xl.parse('Other Events')

# ── Clean Pre-Summit ─────────────────────────────────────────────────────────
pre.columns = ['sno','event','date','organiser','location','key_participants','description','c7','c8']
pre = pre[pre['event'].notna() & (pre['sno'].apply(lambda x: str(x).strip() not in ['S. No.','nan','']).copy())]
pre['organiser'] = pre['organiser'].astype(str).str.replace('^By ', '', regex=True).str.strip()
pre['text']      = pre['event'].fillna('') + ' ' + pre['description'].fillna('')
pre['date_parsed'] = pd.to_datetime(pre['date'], errors='coerce')

# ── Clean Main ───────────────────────────────────────────────────────────────
main.columns = ['sno','event','date','organiser','location','key_participants','theme','link']
main['text']  = main['event'].fillna('') + ' ' + main['theme'].fillna('')

# ── Clean Other ──────────────────────────────────────────────────────────────
other.columns = ['sno','event','date','organiser','location','key_participants','theme','link']
other['text']  = other['event'].fillna('') + ' ' + other['theme'].fillna('')

print(f"Pre-summit: {len(pre)} | Main: {len(main)} | Other: {len(other)} | Total: {len(pre)+len(main)+len(other)}")

# ── Theme Classification ─────────────────────────────────────────────────────
THEMES = {
    'Agriculture & Food':          ['agri','farm','food','crop','rural','fisheries','smallholder'],
    'Health & Medicine':           ['health','medicine','medical','clinical','drug','genomic','healthcare'],
    'Education & Skills':          ['education','skill','learning','school','university','student','workforce','reskill','training'],
    'Governance & Policy':         ['govern','policy','regulation','law','policymaker','diplomacy','compliance'],
    'Climate & Environment':       ['climate','environment','water','carbon','sustainability','energy','weather','flood','disaster'],
    'Gender & Inclusion':          ['women','gender','inclusion','equity','girl','diversity','marginaliz'],
    'Finance & Economy':           ['finance','fintech','banking','payment','economic','investment','startup','manufacturing'],
    'AI Safety & Ethics':          ['safety','trust','ethics','responsible','bias','fairness','harm','risk','accountability'],
    'Infrastructure & Compute':    ['infrastructure','compute','hardware','cloud','sovereign','chip','network','DPI'],
    'Global South & Cooperation':  ['global south','south-south','developing','emerging','africa','multilateral'],
    'Creative & Culture':          ['creative','culture','art','media','entertainment','storytelling','language'],
    'Cybersecurity':               ['cyber','security','privacy','fraud','surveillance','deepfake','attack'],
    'AI Research & Innovation':    ['research','innovation','lab','startup','incubat','science','discovery'],
}

def classify_theme(text):
    text = str(text).lower()
    for theme, kws in THEMES.items():
        if any(k.lower() in text for k in kws):
            return theme
    return 'General AI'

pre['theme_cat']   = pre['text'].apply(classify_theme)
main['theme_cat']  = main['text'].apply(classify_theme)
other['theme_cat'] = other['text'].apply(classify_theme)

# ── Geographic Classification ────────────────────────────────────────────────
def classify_geo(loc):
    if pd.isna(loc): return 'Unknown'
    loc = str(loc).lower()
    india_terms = ['delhi','mumbai','bengaluru','bangalore','hyderabad','chennai','kolkata',
                   'pune','jaipur','chandigarh','lucknow','bhopal','goa','assam','gujarat',
                   'kerala','odisha','india','rajasthan','dehradun','mohali']
    intl_terms  = ['usa','uk','london','geneva','brussels','argentina','seattle','washington','new york','barcelona']
    if any(c in loc for c in india_terms): return 'India'
    if any(c in loc for c in intl_terms):  return 'International'
    return 'Other/Unknown'

pre['geo']   = pre['location'].apply(classify_geo)
other['geo'] = other['location'].apply(classify_geo)

# ── Organiser Type Classification ────────────────────────────────────────────
STAKEHOLDER_TYPES = {
    'Government':       ['government','ministry','meit','stpi','indiaai','policy','public sector','department'],
    'Academia':         ['university','iit','iim','iis','ashoka','college','academic','research institute'],
    'Industry':         ['google','microsoft','aws','nasscom','tcs','infosys','startup','company','industry','corporate'],
    'Civil Society':    ['ngo','foundation','mozilla','iff','freedom','rights','civil society','advocacy'],
    'International':    ['united nations','un ','itu','world bank','oecd','imf','global','international','unesco'],
    'Multi-stakeholder':['multi','stakeholder','consortium','coalition','partnership'],
}

def classify_org(org):
    org = str(org).lower()
    for stype, kws in STAKEHOLDER_TYPES.items():
        if any(k in org for k in kws): return stype
    return 'Other'

pre['org_type'] = pre['organiser'].fillna('').apply(classify_org)

# ── Sentiment Analysis ───────────────────────────────────────────────────────
def get_sentiment(text):
    try: return TextBlob(str(text)).sentiment.polarity
    except: return 0

pre['sentiment']   = pre['description'].fillna('').apply(get_sentiment)
main['sentiment']  = main['text'].apply(get_sentiment)
other['sentiment'] = other['text'].apply(get_sentiment)

# ── Chart Settings ───────────────────────────────────────────────────────────
BG = '#0f1117'
C  = ['#f0a500','#e05c5c','#5cb8e0','#7bc67e','#b07be0',
      '#e08c5c','#5ce0c8','#e05cb8','#a0c0e0','#6090d0','#d0c060','#60d0a0']

# ── Chart 1: Overview Summary Cards ─────────────────────────────────────────
fig = plt.figure(figsize=(14,5)); fig.patch.set_facecolor(BG)
gs = gridspec.GridSpec(1,3,wspace=0.35)
for i,(val,label,col) in enumerate([('807','Total Events\nDocumented','#f0a500'),
                                     ('450','Pre-Summit\nEvents','#5cb8e0'),
                                     ('327','Main Summit\nSessions','#7bc67e')]):
    ax = fig.add_subplot(gs[i]); ax.set_facecolor(BG)
    ax.set_xlim(0,1); ax.set_ylim(0,1)
    ax.add_patch(FancyBboxPatch((0.05,0.05),0.9,0.9,boxstyle='round,pad=0.02',
                                facecolor=col+'22',edgecolor=col,linewidth=2))
    ax.text(0.5,0.62,val,ha='center',va='center',color=col,fontsize=40,fontweight='bold')
    ax.text(0.5,0.28,label,ha='center',va='center',color='#cccccc',fontsize=12,multialignment='center')
    ax.axis('off')
fig.suptitle('AI Impact Summit 2026 — Event Overview',color='white',fontsize=16,fontweight='bold',y=1.02)
plt.tight_layout(); plt.savefig('c1_overview.png',dpi=150,facecolor=BG,bbox_inches='tight'); plt.close()

# ── Chart 2: Pre-summit themes ───────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(11,7)); fig.patch.set_facecolor(BG); ax.set_facecolor(BG)
tc = pre['theme_cat'].value_counts().sort_values()
bars = ax.barh(tc.index,tc.values,color=[C[i%len(C)] for i in range(len(tc))],edgecolor='none',height=0.65,zorder=3)
for bar,val in zip(bars,tc.values):
    ax.text(val+0.8,bar.get_y()+bar.get_height()/2,str(val),va='center',color='white',fontsize=10,fontweight='bold')
ax.set_title('Pre-Summit Events by Theme (450 events)',color='white',fontsize=14,fontweight='bold',pad=12)
ax.set_xlabel('Number of Events',color='#aaaaaa'); ax.tick_params(colors='#aaaaaa',labelsize=9)
ax.spines[:].set_visible(False); ax.xaxis.grid(True,color='#1e1e2e',zorder=0); ax.set_axisbelow(True)
plt.tight_layout(); plt.savefig('c2_pre_themes.png',dpi=150,facecolor=BG); plt.close()

# ── Chart 3: Main summit themes ──────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(11,7)); fig.patch.set_facecolor(BG); ax.set_facecolor(BG)
tc2 = main['theme_cat'].value_counts().sort_values()
bars = ax.barh(tc2.index,tc2.values,color=[C[i%len(C)] for i in range(len(tc2))],edgecolor='none',height=0.65,zorder=3)
for bar,val in zip(bars,tc2.values):
    ax.text(val+0.4,bar.get_y()+bar.get_height()/2,str(val),va='center',color='white',fontsize=10,fontweight='bold')
ax.set_title('Main Summit Sessions by Theme (327 sessions)',color='white',fontsize=14,fontweight='bold',pad=12)
ax.set_xlabel('Number of Sessions',color='#aaaaaa'); ax.tick_params(colors='#aaaaaa',labelsize=9)
ax.spines[:].set_visible(False); ax.xaxis.grid(True,color='#1e1e2e',zorder=0); ax.set_axisbelow(True)
plt.tight_layout(); plt.savefig('c3_main_themes.png',dpi=150,facecolor=BG); plt.close()

# ── Chart 4: Theme comparison ────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(13,7)); fig.patch.set_facecolor(BG); ax.set_facecolor(BG)
all_themes = sorted(set(pre['theme_cat'].unique()) | set(main['theme_cat'].unique()))
pre_c  = [pre['theme_cat'].value_counts().get(t,0) for t in all_themes]
main_c = [main['theme_cat'].value_counts().get(t,0) for t in all_themes]
x = np.arange(len(all_themes)); w = 0.38
ax.bar(x-w/2,pre_c,w,color='#f0a500',label='Pre-Summit Events',edgecolor='none',zorder=3)
ax.bar(x+w/2,main_c,w,color='#5cb8e0',label='Main Summit Sessions',edgecolor='none',zorder=3)
ax.set_xticks(x); ax.set_xticklabels(all_themes,rotation=38,ha='right',color='#cccccc',fontsize=8)
ax.set_title('Theme Comparison: Pre-Summit vs Main Summit',color='white',fontsize=14,fontweight='bold',pad=12)
ax.set_ylabel('Number of Events/Sessions',color='#aaaaaa'); ax.tick_params(colors='#aaaaaa',labelsize=9)
ax.spines[:].set_visible(False); ax.yaxis.grid(True,color='#1e1e2e',zorder=0); ax.set_axisbelow(True)
ax.legend(facecolor='#1a1a2e',labelcolor='white',fontsize=10,framealpha=0.8)
plt.tight_layout(); plt.savefig('c4_theme_compare.png',dpi=150,facecolor=BG); plt.close()

# ── Chart 5: Geography ───────────────────────────────────────────────────────
fig,(ax1,ax2) = plt.subplots(1,2,figsize=(13,6)); fig.patch.set_facecolor(BG)
for ax in (ax1,ax2): ax.set_facecolor(BG)
india_locs = pre[pre['geo']=='India']['location'].fillna('Unknown')
city_map = {}
for loc in india_locs:
    for city in ['Delhi','Mumbai','Bengaluru','Bangalore','Hyderabad','Chennai','Kolkata',
                 'Pune','Jaipur','Chandigarh','Lucknow','Bhopal','Goa','Ahmedabad','Mohali']:
        if city.lower() in str(loc).lower():
            k = 'Bengaluru' if city=='Bangalore' else city
            city_map[k] = city_map.get(k,0)+1; break
    else: city_map['Other India'] = city_map.get('Other India',0)+1
city_df = pd.Series(city_map).sort_values(ascending=True).tail(10)
bars = ax1.barh(city_df.index,city_df.values,color=C[0],edgecolor='none',height=0.65,zorder=3)
for bar,val in zip(bars,city_df.values):
    ax1.text(val+0.3,bar.get_y()+bar.get_height()/2,str(val),va='center',color='white',fontsize=9,fontweight='bold')
ax1.set_title('Top Indian Cities (Pre-Summit)',color='white',fontsize=12,fontweight='bold')
ax1.tick_params(colors='#aaaaaa',labelsize=9); ax1.spines[:].set_visible(False)
ax1.xaxis.grid(True,color='#1e1e2e',zorder=0); ax1.set_axisbelow(True)
geo_counts = pre['geo'].value_counts()
wedges,texts,autotexts = ax2.pie(geo_counts.values,labels=geo_counts.index,autopct='%1.1f%%',
    startangle=140,colors=C[:len(geo_counts)],pctdistance=0.78,wedgeprops=dict(width=0.55,edgecolor=BG,linewidth=2))
for t in texts: t.set_color('#cccccc'); t.set_fontsize(10)
for at in autotexts: at.set_color('white'); at.set_fontsize(9); at.set_fontweight('bold')
ax2.set_title('Geographic Reach',color='white',fontsize=12,fontweight='bold')
fig.suptitle('Geographic Distribution — Pre-Summit Events',color='white',fontsize=14,fontweight='bold')
plt.tight_layout(); plt.savefig('c5_geography.png',dpi=150,facecolor=BG); plt.close()

# ── Chart 6: Top Organisers ──────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(11,6)); fig.patch.set_facecolor(BG); ax.set_facecolor(BG)
org = pre['organiser'].fillna('Unknown').str.replace('^By ','',regex=True).str.strip()
org_counts = org.value_counts().head(15).sort_values()
bars = ax.barh(org_counts.index,org_counts.values,color=[C[i%len(C)] for i in range(len(org_counts))],
               edgecolor='none',height=0.65,zorder=3)
for bar,val in zip(bars,org_counts.values):
    ax.text(val+0.1,bar.get_y()+bar.get_height()/2,str(val),va='center',color='white',fontsize=10,fontweight='bold')
ax.set_title('Top 15 Pre-Summit Event Organisers',color='white',fontsize=14,fontweight='bold',pad=12)
ax.set_xlabel('Number of Events Organised',color='#aaaaaa')
ax.tick_params(colors='#aaaaaa',labelsize=8); ax.spines[:].set_visible(False)
ax.xaxis.grid(True,color='#1e1e2e',zorder=0); ax.set_axisbelow(True)
plt.tight_layout(); plt.savefig('c6_organisers.png',dpi=150,facecolor=BG); plt.close()

# ── Chart 7: Word Cloud ──────────────────────────────────────────────────────
STOPWORDS = {'and','the','for','of','in','on','a','an','to','is','are','with','by','at','from',
             'this','that','how','will','can','ai','india','summit','event','session','2026',
             '2025','impact','indiaai','it','be','as','its','their','has','have','been','not',
             'but','or','they','we','our','which','who','was','were','also'}
all_text = re.sub(r'[^a-zA-Z\s]',' ',
    (' '.join(list(pre['event'].fillna(''))+list(main['event'].fillna(''))+list(other['event'].fillna('')))).lower())
words = [w for w in all_text.split() if len(w)>3 and w not in STOPWORDS]
wc = WordCloud(width=1200,height=600,background_color='#0f1117',colormap='YlOrRd',max_words=120,
               prefer_horizontal=0.8,relative_scaling=0.5).generate_from_frequencies(Counter(words))
fig, ax = plt.subplots(figsize=(14,7)); fig.patch.set_facecolor(BG); ax.set_facecolor(BG)
ax.imshow(wc,interpolation='bilinear'); ax.axis('off')
ax.set_title('Most Frequent Terms Across All AI Impact Summit Events',color='white',fontsize=15,fontweight='bold',pad=14)
plt.tight_layout(); plt.savefig('c7_wordcloud.png',dpi=150,facecolor=BG); plt.close()

# ── Chart 8: Sentiment Analysis ──────────────────────────────────────────────
fig, axes = plt.subplots(1,3,figsize=(14,5)); fig.patch.set_facecolor(BG)
for ax,(df,label,col) in zip(axes,[(pre,'Pre-Summit\nEvents',C[0]),(main,'Main Summit\nSessions',C[2]),(other,'Other\nEvents',C[1])]):
    ax.set_facecolor(BG)
    ax.hist(df['sentiment'],bins=25,color=col,edgecolor='none',zorder=3,alpha=0.85)
    mean_s = df['sentiment'].mean()
    ax.axvline(mean_s,color='white',linestyle='--',linewidth=1.5,zorder=4)
    ax.set_title(f'{label}\n(n={len(df)})',color='white',fontsize=11,fontweight='bold')
    ax.set_xlabel('Sentiment (−1 → +1)',color='#aaaaaa',fontsize=8)
    ax.tick_params(colors='#aaaaaa',labelsize=8); ax.spines[:].set_visible(False)
    ax.yaxis.grid(True,color='#1e1e2e',zorder=0); ax.set_axisbelow(True)
fig.suptitle('Sentiment Analysis — Event Descriptions',color='white',fontsize=14,fontweight='bold')
plt.tight_layout(); plt.savefig('c8_sentiment.png',dpi=150,facecolor=BG); plt.close()

# ── Chart 9: Monthly Trend ───────────────────────────────────────────────────
monthly = pre.dropna(subset=['date_parsed'])
monthly_counts = monthly.groupby(monthly['date_parsed'].dt.to_period('M').astype(str)).size().sort_index()
fig, ax = plt.subplots(figsize=(13,5)); fig.patch.set_facecolor(BG); ax.set_facecolor(BG)
x = range(len(monthly_counts))
ax.fill_between(x,monthly_counts.values,alpha=0.3,color=C[0])
ax.plot(x,monthly_counts.values,color=C[0],linewidth=2.5,marker='o',markersize=6,zorder=3)
for xi,val in zip(x,monthly_counts.values):
    if val >= 20: ax.text(xi,val+1.5,str(val),ha='center',color='white',fontsize=9,fontweight='bold')
ax.set_xticks(list(x)); ax.set_xticklabels(monthly_counts.index.tolist(),rotation=40,ha='right',color='#aaaaaa',fontsize=8)
ax.set_title('Monthly Build-Up of Pre-Summit Events',color='white',fontsize=14,fontweight='bold',pad=12)
ax.set_ylabel('Events per Month',color='#aaaaaa'); ax.tick_params(colors='#aaaaaa')
ax.spines[:].set_visible(False); ax.yaxis.grid(True,color='#1e1e2e',zorder=0); ax.set_axisbelow(True)
plt.tight_layout(); plt.savefig('c9_monthly_trend.png',dpi=150,facecolor=BG); plt.close()

# ── Chart 10: Keywords & Bigrams ─────────────────────────────────────────────
all_desc = re.sub(r'[^a-zA-Z\s]',' ',(' '.join(list(pre['description'].fillna(''))+list(main['text'].fillna('')))).lower())
STOP2 = STOPWORDS | {'such','more','into','through','across','these','those','than','up','all','use','used',
                     'new','well','held','focused','based','including','key','about','other','during'}
words2 = [w for w in all_desc.split() if len(w)>4 and w not in STOP2]
bigrams = [words2[i]+' '+words2[i+1] for i in range(len(words2)-1)]
fig,(ax1,ax2) = plt.subplots(1,2,figsize=(14,6)); fig.patch.set_facecolor(BG)
for ax in (ax1,ax2): ax.set_facecolor(BG)
uni = Counter(words2).most_common(20); u_lbs=[x[0] for x in uni][::-1]; u_vs=[x[1] for x in uni][::-1]
bars=ax1.barh(u_lbs,u_vs,color=C[2],edgecolor='none',height=0.65,zorder=3)
for bar,val in zip(bars,u_vs): ax1.text(val+1,bar.get_y()+bar.get_height()/2,str(val),va='center',color='white',fontsize=8,fontweight='bold')
ax1.set_title('Top 20 Keywords',color='white',fontsize=12,fontweight='bold'); ax1.tick_params(colors='#aaaaaa',labelsize=8)
ax1.spines[:].set_visible(False); ax1.xaxis.grid(True,color='#1e1e2e',zorder=0); ax1.set_axisbelow(True)
bg = Counter(bigrams).most_common(20); b_lbs=[x[0] for x in bg][::-1]; b_vs=[x[1] for x in bg][::-1]
bars2=ax2.barh(b_lbs,b_vs,color=C[0],edgecolor='none',height=0.65,zorder=3)
for bar,val in zip(bars2,b_vs): ax2.text(val+0.3,bar.get_y()+bar.get_height()/2,str(val),va='center',color='white',fontsize=8,fontweight='bold')
ax2.set_title('Top 20 Bigrams',color='white',fontsize=12,fontweight='bold'); ax2.tick_params(colors='#aaaaaa',labelsize=8)
ax2.spines[:].set_visible(False); ax2.xaxis.grid(True,color='#1e1e2e',zorder=0); ax2.set_axisbelow(True)
fig.suptitle('Text Mining — Most Frequent Terms in Event Descriptions',color='white',fontsize=14,fontweight='bold')
plt.tight_layout(); plt.savefig('c10_keywords.png',dpi=150,facecolor=BG); plt.close()

# ── Chart 11: Organiser Type Donut ───────────────────────────────────────────
fig, ax = plt.subplots(figsize=(9,5)); fig.patch.set_facecolor(BG); ax.set_facecolor(BG)
ot = pre['org_type'].value_counts()
wedges,texts,autotexts = ax.pie(ot.values,labels=ot.index,autopct='%1.1f%%',startangle=140,
    colors=C[:len(ot)],pctdistance=0.78,wedgeprops=dict(width=0.55,edgecolor=BG,linewidth=2))
for t in texts: t.set_color('#cccccc'); t.set_fontsize(10)
for at in autotexts: at.set_color('white'); at.set_fontsize(9); at.set_fontweight('bold')
ax.set_title('Organiser Type — Pre-Summit Events',color='white',fontsize=14,fontweight='bold',pad=14)
plt.tight_layout(); plt.savefig('c11_stakeholders.png',dpi=150,facecolor=BG); plt.close()

# ── Chart 12: Theme × Organiser Heatmap ─────────────────────────────────────
fig, ax = plt.subplots(figsize=(13,7)); fig.patch.set_facecolor(BG); ax.set_facecolor(BG)
pivot = pre.groupby(['org_type','theme_cat']).size().unstack(fill_value=0)
im = ax.imshow(pivot.values,cmap='YlOrRd',aspect='auto')
ax.set_xticks(range(len(pivot.columns))); ax.set_xticklabels(pivot.columns,rotation=38,ha='right',color='#cccccc',fontsize=8)
ax.set_yticks(range(len(pivot.index))); ax.set_yticklabels(pivot.index,color='#cccccc',fontsize=10)
mx = pivot.values.max()
for i in range(pivot.shape[0]):
    for j in range(pivot.shape[1]):
        val = pivot.values[i,j]
        if val > 0:
            ax.text(j,i,str(val),ha='center',va='center',
                    color='white' if val>mx*0.5 else '#333',fontsize=9,fontweight='bold')
ax.set_title('Theme × Organiser Type Heatmap',color='white',fontsize=14,fontweight='bold',pad=12)
ax.spines[:].set_visible(False)
cbar = fig.colorbar(im,ax=ax,fraction=0.03); cbar.ax.tick_params(colors='#aaaaaa')
plt.tight_layout(); plt.savefig('c12_theme_org_heatmap.png',dpi=150,facecolor=BG); plt.close()

print("All 12 charts generated successfully.")

# ── Print Summary Stats ──────────────────────────────────────────────────────
print("\n=== KEY FINDINGS ===")
print(f"Total events documented: {len(pre)+len(main)+len(other)}")
print(f"Pre-summit top theme: {pre['theme_cat'].value_counts().index[0]} ({pre['theme_cat'].value_counts().values[0]} events)")
print(f"Main summit top theme: {main['theme_cat'].value_counts().index[0]} ({main['theme_cat'].value_counts().values[0]} sessions)")
print(f"Most active organiser: {pre['organiser'].value_counts().index[0]} ({pre['organiser'].value_counts().values[0]} events)")
print(f"Share of events in India: {(pre['geo']=='India').sum()/len(pre)*100:.1f}%")
print(f"Avg sentiment (pre-summit): {pre['sentiment'].mean():.3f}")
print(f"Avg sentiment (main summit): {main['sentiment'].mean():.3f}")
